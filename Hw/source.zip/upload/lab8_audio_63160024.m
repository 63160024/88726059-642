##63160024
clc;clear
##no1
## Writing an audio file
filename='cosine.ogg';
fs=4400;
t=0:1/fs:3;
w=2*pi*50*t;
signal=cos(w);
audiowrite(filename, signal, fs);
[M, fs] = audioread(filename);
sound(M) ## read audio
## look sound signal
figure(1), plot(t,signal,'b'),title('sound')

##no2
filename='cosine2.ogg';
fs=44100;
t=0:1/fs:4;
w=2*pi*20*t;
signal=cos(w);
audiowrite(filename, signal, fs);
[M, fs] = audioread(filename);
sound(M) ## read audio
## look sound signal
figure(1), plot(t,signal,'b'),title('sound')

##no3
## Writing an audio file
load sound_data %data matrix for sound
filename='sound1.ogg';
fs = 8192;
audiowrite(filename, sound_data, fs);
## read an audio file
[dataY, fs] = audioread(filename);
sound(dataY)

##no4
myVoice = audiorecorder(8000,8) % record
disp('Start speaking.');
recordblocking(myVoice,5); % Record 5 seconds
play(myVoice);
data = getaudiodata(myVoice); %get data
plot(data)