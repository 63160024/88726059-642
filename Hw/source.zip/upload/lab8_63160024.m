##63160024
clear
##no1
tx = ty = linspace (-8, 8, 41)';
[xx, yy] = meshgrid (tx, ty);
r = sqrt(xx.^2 + yy.^2);
tz = sin(r)./r; 
mesh (tx, ty, tz); 
xlabel ("tx");
ylabel ("ty"); 
zlabel ("tz");

##no2
tx = ty = linspace (-8, 8, 41)';
[xx, yy] = meshgrid (tx, ty);
r = sqrt(xx.^2 + yy.^2);
tz = sin(r)./r^2; 
mesh (tx, ty, tz); 
xlabel ("tx");
ylabel ("ty"); 
zlabel ("tz");

##no3
tx = ty = linspace (-8, 8,41)';
[xx, yy] = meshgrid (tx, ty);
r = sqrt(xx.^2 + yy.^2);
tz = sin(r)./r+2; 
mesh (tx, ty, tz); 
xlabel ("tx");
ylabel ("ty"); 
zlabel ("tz");

##no4
tx = ty = linspace (-8, 8,41)';
[xx, yy] = meshgrid (tx, ty);
r = sqrt(xx.^2 + yy.^2);
tz = sin(r)./r-2; 
mesh (tx, ty, tz); 
xlabel ("tx");
ylabel ("ty"); 
zlabel ("tz");

##no5
tx = ty = linspace (-8, 8,41)';
[xx, yy] = meshgrid (tx, ty);
r = sqrt(xx.^2 + yy.^2);
tz = sin(r)./r*2; 
mesh (tx, ty, tz); 
xlabel ("tx");
ylabel ("ty"); 
zlabel ("tz");

##no6
tx = ty = linspace (-8, 8,41)';
[xx, yy] = meshgrid (tx, ty);
r = sqrt(xx.^2 + yy.^2);
tz = sin(r)./r/2; 
mesh (tx, ty, tz); 
xlabel ("tx");
ylabel ("ty"); 
zlabel ("tz");

##no7
tx = ty = linspace (-8, 8,41)';
[xx, yy] = meshgrid (tx, ty);
r = sqrt(xx.^2 + yy.^2);
tz = sin(r)./r^2; 
mesh (tx, ty, tz); 
xlabel ("tx");
ylabel ("ty"); 
zlabel ("tz");

##no8
tx = ty = linspace (-8, 8,41)';
[xx, yy] = meshgrid (tx, ty);
r = sqrt(xx.^2 + yy.^2);
tz = sin(r)./sqrt(r); 
mesh (tx, ty, tz); 
xlabel ("tx");
ylabel ("ty"); 
zlabel ("tz");

##no9
tx = ty = linspace (-8, 8,41)';
[xx, yy] = meshgrid (tx, ty);
r = sqrt(xx.^2 + yy.^2);
tz = cos(r)./r; 
mesh (tx, ty, tz); 
xlabel ("tx");
ylabel ("ty"); 
zlabel ("tz");

##no10
t = 0:pi/50:10*pi; %Z
x = sin(t); % x
y = cos(t); %y 
figure,plot3(x,y,t); 
##grid on 
xlabel ("x"); 
ylabel ("y"); 
zlabel ("t");

##11
t = 0:pi/50:2*pi; %Z
x = sin(t); % x
y = cos(t); %y 
figure,plot3(x,y,t); 
##grid on 
xlabel ("x"); 
ylabel ("y"); 
zlabel ("t");

##no12
n = 200;
t = 0:pi/50:n*pi; %Z
st = sin(t); % x
ct = cos(t); %y 
figure,plot3(st,ct,t),title(num2str(n)); 
##grid on

##no13
t = 0:0.1:10*pi; 
r = linspace (0, 1, numel (t));
z = linspace (0, 1, numel (t));
x = r.*sin(t); 
y = r.*cos(t), 
plot3 (x, y, z); 
xlabel ("r.*sin(t)"); 
ylabel ("r.*cos(t)"); 
zlabel ("z"); 
title ("plot3 display of 3-D helix");
##grid on; � figure,plot(r)

##no14
t = 0:0.1:10*pi; 
r = linspace (0, 1, numel (t));
z = linspace (0, 1,numel (t));
x = r.*sin(t); 
y = r.*cos(t), 
z = 1./z;
plot3 (x, y, z); 
xlabel ("r.*sin(t)"); 
ylabel ("r.*cos(t)"); 
zlabel ("z"); 
title ("plot3 display of 3-D helix");

##no15
[X,Y] = meshgrid(-8:.5:8);
R = sqrt(X.^2 + Y.^2);
Z = sin(R)./R;
surf(X,Y,Z);

##no16
[X,Y] = meshgrid(-8:.5:8);
R = sqrt(X.^2 + Y.^2)+eps;
Z = sin(R)./R;
surf(X,Y,Z,'FaceColor','y','EdgeColor','none');
light()

##no17
[X,Y] = meshgrid(-8:.5:8);
R = sqrt(X.^2 + Y.^2)+eps;
Z = sin(R)./R;
surf(X,Y,Z,'FaceColor','r','EdgeColor','k');

##no18
[X,Y] = meshgrid(-8:.5:8);
R = sqrt(X.^2 + Y.^2)+eps;
Z = sin(R)./R;
surf(X,Y,Z,'FaceColor','r','EdgeColor','c');