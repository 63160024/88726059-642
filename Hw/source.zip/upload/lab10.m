claear
##A = [2 8 3 8 4 3];
##n = 2;
##hist(A,3)
##[freq, cent] = hist(A,3);
##
##A = [2 8 3 8 4 3];
##n = 3;
##hist(A,2)
##[freq, cent] = hist(A,2);

A = [1 2 2 3 4 4];
n = 4;
hist(A,4)
[freq, cent] = hist(A,4);

A = [1 2 2 3 4 4];
n = 4;
hist(A,2)
[freq, cent] = hist(A,2);

TrainFeature = []
label = []
trainFeature = []
result = euclideanDist(trainFeature)