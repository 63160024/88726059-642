#63160024
clc;clear;close all

##no1 2D
t = 0:pi/24:2*pi;
x = sin(t);
comet(x);

##no2
t = 0:pi/24:4*pi;
x = sin(t);
comet(x);
figure,comet(x);

##no3
t = 0:pi/24:2*pi;
x = sin(t);
y = cos(t);
comet(x);
figure(1),comet(x,y);

##no4
t = 0:.01:2*pi;
x = cos(2*t).*(cos(t).^2);
y = sin(2*t).*(sin(t).^2);
comet(x,y);

##no5 3D
t = 0:pi/24:2*pi;
x = sin(t);
comet3(x);

##no6
t = 0:pi/24:4*pi;
x = sin(t);
comet3(x);

##no7
t = 0:pi/36:6*pi;
x = sin(t);
y = cos(t);
comet3(x,y,t);

##no8
t = 0:pi/100:2*pi;
x = sin(t).^2;
y = cos(t).^2;
comet3(x,y,t);

##no9
t = 0:pi/24:2*pi;
x = (cos(t));
y = (-cos(t));
hold on;
comet3(x,y,t);
hold on;
comet3(y,x,t);

##no10
t = 0:0.1:10*pi;
r = linspace(0, 1, numel(t));
z = linspace(0, 1, numel(t));
axis([-1 1 -1 1 0 1])
hold on
for ii=1:length(r)
    plot3 (r(ii)*sin(t(ii)),r(ii)*cos(t(ii)),z(ii),'*');
    pause(.001)
end   

##Hw9
##no1
t = 0:pi/24:2*pi;
x = (cos(t));
y = (-cos(t));
hold on;
comet(t,x);
hold on;
comet(t,y);

##no2
t = 0:pi/36:6*pi;
x = sin(t);
y = cos(t);
comet3(y,x,t);

##no3
t = 0:0.1:10*pi;
r = linspace(0, 1, numel(t));
z = linspace(1, 0, numel(t));
axis([-1 1 -1 1 0 1])
hold on
for ii=1:length(r)
    plot3 (r(ii)*sin(t(ii)),r(ii)*cos(t(ii)),z(ii),'*');
    pause(.001)
end 

##no4
h = 0; k = 0; r = 6;
t = 0:pi/4:8*pi;
x = h + r*sin(t);
y = h + r*cos(t);
comet3(y,x,t);