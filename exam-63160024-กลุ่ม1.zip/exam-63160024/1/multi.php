<?php
$multi = [];
if (isset($_GET['show'])) {
    $multi = $_GET['show'];
}else {
    $multi = [
        <tr>
            <tr align="center"><th>สูตรคูณแม่ a=prompt</th>                    
        </tr>
        <tr>
            <th></th><th></th><th></th>          
        </tr> 
    ];
    }
?>